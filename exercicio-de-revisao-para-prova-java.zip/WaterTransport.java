public class WaterTransport extends Transport {
    // Atributos adicionais específicos para veículos marítimos
    private int beam;       // Boca do veículo em metros
    private int draught;    // Calado do veículo em metros

    // Construtor da classe WaterTransport que chama o construtor da classe pai (Transport)
    public WaterTransport(String name, double height, double length, int payload, int speed, int beam, int draught) {
        // Chama o construtor da classe pai para inicializar os atributos comuns
        super(name, height, length, payload, speed);
        
        // Inicializa os atributos específicos para veículos marítimos
        this.beam = beam;
        this.draught = draught;
    }
}
