import java.util.ArrayList;
//import java.util.Collections; // Adicionando a importação necessária

public class Catalog {
    private ArrayList<Transport> vehicles;

    public Catalog() {
        this.vehicles = new ArrayList<>();
    }

    public void insertVehicle(Transport vehicle) {
        vehicles.add(vehicle);
    }

    public void displayVehicles() {
        Collections.selectionSort(vehicles); // Chamando o método selectionSort de Collections

        for (Transport vehicle : vehicles) {
            System.out.println(vehicle.getName() + " - Speed: " + vehicle.getSpeed());
            System.out.println("\n");
        }
    }
}
