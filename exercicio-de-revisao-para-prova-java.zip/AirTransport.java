public class AirTransport extends Transport {
    // Atributos adicionais específicos para veículos aéreos
    private int range;          // Autonomia de voo em quilômetros
    private double wingspan;    // Envergadura da asa em metros

    // Construtor da classe AirTransport que chama o construtor da classe pai (Transport)
    public AirTransport(String name, double height, double length, int payload, int speed, int range, double wingspan) {
        // Chama o construtor da classe pai para inicializar os atributos comuns
        super(name, height, length, payload, speed);
        
        // Inicializa os atributos específicos para veículos aéreos
        this.range = range;
        this.wingspan = wingspan;
    }
}
