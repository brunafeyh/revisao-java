import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.printf("Exibindo os veículos ordenados por velocidade:\n\n");
    
        // Criando alguns veículos para teste
        AirTransport airplane = new AirTransport("Boeing 747", 10.5, 70.0, 200, 900, 15000, 60.5);
        LandTransport car = new LandTransport("Toyota Camry", 1.5, 4.5, 5, 180, "V6", "4");
        WaterTransport ship = new WaterTransport("Cargo Ship", 20.0, 150.0, 10000, 40, 25, 10);

        // Adicionando os veículos ao catálogo
        Catalog catalog = new Catalog();
        catalog.insertVehicle(airplane);
        catalog.insertVehicle(car);
        catalog.insertVehicle(ship);

        // Exibindo os veículos ordenados por velocidade
        catalog.displayVehicles();
    }
}
