public class LandTransport extends Transport {
    // Atributos adicionais específicos para veículos terrestres
    private String engine;  // Tipo de motor
    private String wheels;  // Tipo de rodas

    // Construtor da classe LandTransport que chama o construtor da classe pai (Transport)
    public LandTransport(String name, double height, double length, int payload, int speed, String engine, String wheels) {
        // Chama o construtor da classe pai para inicializar os atributos comuns
        super(name, height, length, payload, speed);
        
        // Inicializa os atributos específicos para veículos terrestres
        this.engine = engine;
        this.wheels = wheels;
    }
}
