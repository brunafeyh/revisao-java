public class Transport implements Comparable<Transport> {
    // Atributos da classe Transport
    private String name;    // Nome do veículo de transporte
    private double height;  // Altura do veículo de transporte em metros
    private double length;  // Comprimento do veículo de transporte em metros
    private int payload;    // Capacidade de carga do veículo de transporte em toneladas
    private int speed;      // Velocidade do veículo de transporte em quilômetros por hora

    // Construtor da classe Transport
    public Transport(String name, double height, double length, int payload, int speed) {
        this.name = name;
        this.height = height;
        this.length = length;
        this.payload = payload;
        this.speed = speed;
    }

    // Método compareTo para implementar a interface Comparable
    @Override
    public int compareTo(Transport other) {
        // Compara os veículos com base na sua velocidade
        return Integer.compare(this.speed, other.speed);
    }

    // Getters para acessar os atributos privados da classe
    public String getName() {
        return name;
    }

    public int getSpeed() {
        return speed;
    }
}
